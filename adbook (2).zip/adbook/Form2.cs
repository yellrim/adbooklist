﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

public class Info
{
    string name;
    string phone;
    string addr;
}

namespace adbook
{
    public partial class Form2 : Form
    {

        int input;

        public string name = string.Empty;
        //public string phone = string.Empty;
        //public string addr = string.Empty;
        List<string> listname = new List<string>();
        //List<string> listphone = new List<string>();
        //List<string> listaddr = new List<string>();

        //string[] arrusername = new string[10];
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            //객체로 만들기
            //Info uesr_info = new Info();
            //uesr_info.name = name;
            //uesr_info.phone = phone;
            //uesr_info.addr = addr;
            main();
        }

        public void main()
        {
            Console.Clear();
            MainView();
            //if(name != "")
            //Console.WriteLine("성함 {0} 정보 저장. ",name);

            input = int.Parse(Console.ReadLine());

            Console.WriteLine("입력값 : " + input);

            if (input == 0)
            {
                Console.Clear();
                Test1();

            }
            else if (input == 1)
            {
                Console.Clear();
                Test2();
            }
            else if (input == 2)
            {
                Console.Clear();
                Test3();
            }
            else if (input == 3)
            {
                Console.Clear();
                Test4();
            }
            else if (input == 4)
            {
                Console.Clear();
                Test5();
            }
            else if (input == 5)
            {

            }

        }

        public void MainView()
        {
            Console.WriteLine("-----------------------");
            Console.WriteLine("0. 정보 입력");
            Console.WriteLine("1. 정보 검색");
            Console.WriteLine("2. 정보 수정");


            Console.WriteLine("3. 정보 삭제");
            Console.WriteLine("4. 전체 출력");
            Console.WriteLine("5. 프로그램 종료");
            Console.WriteLine("-----------------------");
            Console.WriteLine("메뉴를 선택하세요");
        }

        public void Test1()
        {

            /*정보입력*/
            Console.WriteLine("--정보입력화면--");

            Console.Write("이름 입력 : "); name = Console.ReadLine();
            //Console.Write("번호 입력 : "); phone = Console.ReadLine();
            //Console.Write("주소 입력 : "); addr = Console.ReadLine();
            //arrusername[0] = name;

            // 리스트에 저장해주는 코드
            listname.Add(name);
            //listname.Add(phone);
            //listname.Add(addr);

            Console.ReadLine();

            main();
        }
        public void Test2()
        {
            /*정보검색*/
            Console.WriteLine("이름 입력 : ");
            Console.ReadLine();
            Console.WriteLine("-----------------------");
            Console.WriteLine("이름 : ");
            Console.WriteLine("전화 : ");
            Console.WriteLine("주소 : ");
            Console.WriteLine("-----------------------");

            Console.ReadLine();

            main();
        }
        public void Test3()
        {
            /*정보수정*/
            Console.WriteLine("이름 입력 : ");
            Console.WriteLine("-----------------------");
            Console.WriteLine("이름 : ");
            Console.WriteLine("전화 : ");
            Console.WriteLine("주소 : ");
            Console.WriteLine("-----------------------");

            Console.ReadLine();
            main();
        }
        public void Test4()
        {
            /*정보삭제*/
            Console.WriteLine("이름 입력 : ");

            Console.ReadLine();
            main();
        }
        public void Test5()
        {
            /*전체출력*/
            for (int i = 0; i < listname.Count; i++)
            {
                Console.WriteLine("-----------{0}------------",i);
                Console.WriteLine("이름 : " + listname[i].ToString());
                //Console.WriteLine("전화 : " + listphone[i].ToString());
                //Console.WriteLine("주소 : " + listaddr[i].ToString());
                Console.WriteLine("------------------------");
            };
            
            Console.ReadLine();
            //name = "";
            main();

        }

    }
}